﻿nendSDK for Android

nendをAndroidで利用するためのSDKです。

・ドキュメント
https://github.com/fan-ADN/nendSDK-Android/wiki

・サンプル
https://github.com/fan-ADN/nendSDK-Android

-----------------------------------------------------------
nend / http://nend.net 
 (c) F@N Communications, Inc.
-----------------------------------------------------------
